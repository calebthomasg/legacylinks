#include <lvgl.h>
#include <string>
#include <cstring>
#include <fstream>
#include <cassert>
#include <iostream>
struct String:std::string {using std::string::string;String(){}String(char c):std::string(1,c){}String(const std::string&s):std::string(s){}String(unsigned n):std::string(std::to_string(n)){} };
enum Page{DIAGNOSTIC,OPEN,DASH,SETTINGS,NETWORKS,PASSWORD,UPDATES,LOCAL_UPDATES,SIGNAL};
static Page page=DIAGNOSTIC;static bool scanRequested=false,scanning=false,connecting=false,credentialsVerified=true;static int scheduledAction=0,retryCount=0;static bool retrySaved=false;
static lv_obj_t *statusLabel=nullptr,*passwordBox=nullptr,*networkList=nullptr,*image=nullptr,*statusIcon=nullptr,*statusGlyph=nullptr;
static String selectedSSID="SpectrumSetup-AD",wifiMessage="Connection failed; reason 2\nRetry saved Wi-Fi in Settings";
static const int WL_CONNECTED=1;struct IP{String toString(){return "192.168.1.185";}};struct W{int state=1;int status(){return state;}String SSID(){return selectedSSID;}IP localIP(){return {};}}WiFi;
static bool loadNetwork(String&a,String&b){a="different";b="";return false;}
static void showNetworks(){}static void showSettings();static void showDiagnostics(){}static void connectToNetwork(){}

#define TRAILHEAD_VERSION "0.1.8"
struct Release {const char *version="0.1.9",*notes="Hosted update test. Confirms direct download and saved Wi-Fi after restart.";}cloudRelease;
static bool cloudBusy=false,cloudAvailable=true,otaEnabled=false;static char cloudMessage[160]="New update available";
static bool startCloudJob(bool){return true;}static void showLocalUpdates(){}static void showUpdates();
static bool retryStoredNetwork(){return true;}static void cancelNetwork(){}struct Prefs{void remove(const char*){}}prefs;

static bool lastConnectValid=true;static unsigned lastConnectMs=6500,lastConnectAttempts=2,connectionCycleStarted=0;unsigned millis(){return 6500;}static void showSettings(){}
static lv_color_t blue(){return lv_color_hex(0x0a264f);}static lv_color_t sand(){return lv_color_hex(0xf5f3ea);}
static lv_obj_t* label(const char *text,int y,int width=330){auto *o=lv_label_create(lv_scr_act());lv_label_set_text(o,text);lv_obj_set_width(o,width);lv_obj_set_style_text_align(o,LV_TEXT_ALIGN_CENTER,0);lv_obj_set_style_text_color(o,blue(),0);lv_obj_align(o,LV_ALIGN_TOP_MID,0,y);return o;}
static lv_obj_t* button(const char *text,int y,lv_event_cb_t cb,int width=240){auto *o=lv_btn_create(lv_scr_act());lv_obj_set_size(o,width,46);lv_obj_align(o,LV_ALIGN_TOP_MID,0,y);lv_obj_set_style_bg_color(o,blue(),0);lv_obj_set_style_radius(o,23,0);auto *l=lv_label_create(o);lv_label_set_text(l,text);lv_obj_center(l);lv_obj_add_event_cb(o,cb,LV_EVENT_CLICKED,nullptr);return o;}
static void clearPage(Page next){page=next;if(next!=NETWORKS)scanRequested=false;statusIcon=statusGlyph=nullptr;statusLabel=passwordBox=networkList=image=nullptr;lv_obj_clean(lv_scr_act());lv_obj_clear_flag(lv_scr_act(),LV_OBJ_FLAG_SCROLLABLE);lv_obj_set_style_bg_color(lv_scr_act(),sand(),0);lv_obj_set_style_text_font(lv_scr_act(),&lv_font_montserrat_16,0);}
static String wifiStatus(){
 if(WiFi.status()==WL_CONNECTED)return String("Connected\n")+WiFi.SSID()+"\n"+WiFi.localIP().toString()+ (credentialsVerified?"\nSaved for next startup":"\nSettings not saved")+(lastConnectValid?String("\nJoined in ")+String(unsigned(lastConnectMs/1000))+"s / "+String(lastConnectAttempts)+" attempt(s)":"");
 if(connecting||scheduledAction==2)return String("Connecting...\nAttempt ")+String(unsigned(retryCount+1))+(retrySaved?" of 3":" of 1")+"\nElapsed "+String(unsigned((millis()-connectionCycleStarted)/1000))+"s";
 if(scanning||scheduledAction==1)return "Scanning networks...";
 return wifiMessage;
}
static void refreshDashboard(){
 if(page!=DASH||!statusLabel)return;
 lv_label_set_text(statusLabel,wifiStatus().c_str());
 bool online=WiFi.status()==WL_CONNECTED;bool busy=connecting||scheduledAction==2||scanning||scheduledAction==1;
 lv_obj_set_style_bg_color(statusIcon,lv_color_hex(online?0x36bfaf:(busy?0x0a264f:0xf97370)),0);
 lv_label_set_text(statusGlyph,online?LV_SYMBOL_OK:(busy?"...":LV_SYMBOL_CLOSE));lv_obj_center(statusGlyph);
}
static void showDashboard(){
 clearPage(DASH);label("Trailhead Compass",70);label("Wireless update v0.1.11",110);
 statusIcon=lv_obj_create(lv_scr_act());lv_obj_remove_style_all(statusIcon);lv_obj_set_size(statusIcon,30,30);lv_obj_align(statusIcon,LV_ALIGN_TOP_LEFT,62,180);
 lv_obj_set_style_radius(statusIcon,LV_RADIUS_CIRCLE,0);lv_obj_set_style_bg_opa(statusIcon,LV_OPA_COVER,0);lv_obj_clear_flag(statusIcon,LV_OBJ_FLAG_SCROLLABLE|LV_OBJ_FLAG_CLICKABLE);
 statusGlyph=lv_label_create(statusIcon);lv_obj_set_style_text_color(statusGlyph,lv_color_hex(0xffffff),0);
 statusLabel=label("",180,300);lv_obj_align(statusLabel,LV_ALIGN_TOP_LEFT,104,180);lv_obj_set_style_text_align(statusLabel,LV_TEXT_ALIGN_LEFT,0);refreshDashboard();
 button("Settings",300,[](lv_event_t*){showSettings();});button("Alignment test",356,[](lv_event_t*){showDiagnostics();});
}
static uint16_t pixels[480*480];
void flush(lv_disp_drv_t*d,const lv_area_t*a,lv_color_t*c){for(int y=a->y1;y<=a->y2;y++)for(int x=a->x1;x<=a->x2;x++)pixels[y*480+x]=(c++)->full;lv_disp_flush_ready(d);}
void shot(const char*name){lv_obj_update_layout(lv_scr_act());lv_refr_now(nullptr);std::ofstream o(name,std::ios::binary);o<<"P6\n480 480\n255\n";for(auto v:pixels){char rgb[3]={char(((v>>11)&31)*255/31),char(((v>>5)&63)*255/63),char((v&31)*255/31)};o.write(rgb,3);}}
int main(){lv_init();static lv_color_t buf[480*40];static lv_disp_draw_buf_t db;lv_disp_draw_buf_init(&db,buf,nullptr,480*40);static lv_disp_drv_t d;lv_disp_drv_init(&d);d.hor_res=480;d.ver_res=480;d.draw_buf=&db;d.flush_cb=flush;lv_disp_drv_register(&d);

showDashboard();shot("retry-connected.ppm");lv_area_t a;lv_obj_get_coords(statusLabel,&a);assert(a.y2<300);WiFi.state=0;connecting=true;retrySaved=true;retryCount=1;showDashboard();shot("retry-connecting.ppm");puts("PASS: live elapsed/attempt status rendered with real LVGL; connected status fits above buttons");}

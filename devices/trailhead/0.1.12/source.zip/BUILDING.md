# Building and testing v0.1.12

Full development/acceptance notes are in README.md.

Firmware: open firmware/TrailheadFirstBoot/TrailheadFirstBoot.ino with the same working Arduino-ESP32 3.0.2 + 3.0.2-h SDK setup used for v0.1.11. Use LVGL 8.3.10 and this lv_conf.h. The high-performance SDK is essential: 64-byte cache and XIP PSRAM are enforced by compile guards. USB CDC on boot must be disabled. Do not substitute an ordinary SDK or change LCD timing. Compile with 16 MB flash, OPI PSRAM, qio, supplied partitions.csv and 4 MB app limit. This release is app-only, not a 16 MB factory image.

To regenerate the supplied icon/background assets on a development computer:

    python3 -m pip install pillow numpy cairosvg
    python3 generate-assets.py

The generator currently uses /usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf; change only that path to the same font on another OS. Generated C++ is already included, so regeneration is optional.

Native Linux/macOS tests require Python 3, gcc/g++, OpenSSL and libcJSON development libraries for the cloud test. Tests compile and execute extracted production logic with mocked Wi-Fi/HTTP/flash, plus real LVGL UI input:

    python3 tests/run-network-tests.py
    python3 tests/run-ota-tests.py
    python3 tests/run-cloud-tests.py
    LVGL_PATH=/absolute/path/to/lvgl python3 tests/run-dial-tests.py

The last command builds LVGL host objects in a temporary directory and writes PPM renders beside this file. It does not need the ESP32 or a serial connection. LVGL_PATH must point to version 8.3.10 with lvgl.h and src/. Hardware acceptance is separate; see README.md.

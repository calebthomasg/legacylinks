from pathlib import Path
import io,re
import numpy as np
from PIL import Image,ImageDraw,ImageFont
import cairosvg
root=Path(__file__).resolve().parent
out=root/'firmware/TrailheadFirstBoot'
icons=['63-home','20-heart','64-wifi','21-avatar','409-wrench','236-alarm','18-location-pin','448-pet-print']
header='#pragma once\n#include <lvgl.h>\nextern const lv_img_dsc_t DIAL_BACKGROUND;\nextern const lv_img_dsc_t DIAL_OPEN;\nextern const lv_img_dsc_t DIAL_ICONS[2][8];\n'
cpp='#include "DialAssets.h"\n'
def emit(name,img,alpha=False):
 global cpp
 a=np.array(img.convert('RGBA'),dtype=np.uint16)
 if name=='background':
  bayer=np.array([[0,8,2,10],[12,4,14,6],[3,11,1,9],[15,7,13,5]])/16-.5
  noise=np.tile(bayer,(img.height//4,img.width//4))
  for c,step in enumerate([8,4,8]):a[:,:,c]=np.clip(a[:,:,c].astype(float)+noise*step,0,255).astype('uint16')
 rgb=((a[:,:,0]>>3)<<11)|((a[:,:,1]>>2)<<5)|(a[:,:,2]>>3)
 data=np.stack([rgb&255,rgb>>8,a[:,:,3]],axis=-1).astype('uint8') if alpha else np.stack([rgb&255,rgb>>8],axis=-1).astype('uint8')
 b=data.tobytes();cpp+='static const uint8_t '+name+'_pixels[]={\n'+',\n'.join(','.join(map(str,b[i:i+100])) for i in range(0,len(b),100))+'\n};\n'
 return '{ {0,0,0,0,0},0,nullptr}' if False else f'{{{{{ "LV_IMG_CF_TRUE_COLOR_ALPHA" if alpha else "LV_IMG_CF_TRUE_COLOR"},0,0,{img.width},{img.height}}},{len(b)},{name}_pixels}}'
# Fixed gradient with a pre-rendered subtle Sand halo at the selection point.
y,x=np.mgrid[:480,:480];t=x/479
left=np.array([20,184,166]);right=np.array([77,170,245]);rgb=left[None,None,:]*(1-t[:,:,None])+right[None,None,:]*t[:,:,None]
halo=np.exp(-((x-240)**2+(y-416)**2)/(2*32**2))*.40
rgb=rgb*(1-halo[:,:,None])+np.array([245,241,230])*halo[:,:,None]
bg=Image.fromarray(rgb.astype('uint8'),'RGB');d=ImageDraw.Draw(bg)
d.ellipse((129,129,351,351),fill='#0f1d3a')
# Center preserves the gradient; stationary Sand arc points at bottom selection.
d.arc((132,132,348,348),52,128,fill='#f5f1e6',width=22)
for yy in range(153,328):
 for xx in range(153,328):
  if (xx-240)**2+(yy-240)**2<=87**2:bg.putpixel((xx,yy),tuple(rgb[yy,xx].astype('uint8')))
desc=emit('background',bg);cpp+='const lv_img_dsc_t DIAL_BACKGROUND='+desc+';\n'
word=Image.new('RGBA',(140,52));font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',40);dw=ImageDraw.Draw(word);dw.text((70,26),'open',font=font,fill='#f5f1e6',anchor='mm')
desc=emit('openword',word,True);cpp+='const lv_img_dsc_t DIAL_OPEN='+desc+';\n'
rows=[]
for variant,color in enumerate(['#0f1d3a','#f5f1e6']):
 row=[]
 for i,icon in enumerate(icons):
  svg=(root/'assets'/f'system-solid-{icon}.svg').read_text();svg=re.sub(r'#[0-9a-fA-F]{6}',color,svg)
  img=Image.open(io.BytesIO(cairosvg.svg2png(bytestring=svg.encode(),output_width=52,output_height=52)))
  row.append(emit(f'icon_{variant}_{i}',img,True))
 rows.append('{'+','.join(row)+'}')
cpp+='const lv_img_dsc_t DIAL_ICONS[2][8]={'+','.join(rows)+'};\n'
(out/'DialAssets.h').write_text(header);(out/'DialAssets.cpp').write_text(cpp)
bg.save(root/'background.png')
print('Generated exact-palette RGB565 background and 16 alpha icons; RGB565 quantizes colors to display precision.')

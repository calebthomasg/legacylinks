/* LegacyLink Trailhead Compass 0.1.10 — ESP32-S3-Touch-LCD-2.8C.
   Hardware validation is required. See docs/DEVELOPMENT.md. */
#include <Arduino.h>
#if ARDUINO_USB_CDC_ON_BOOT
#error "This build requires USB CDC on boot disabled."
#endif
// No application serial initialization/output in this diagnostic.
struct SilentLog { void begin(unsigned long){} void println(const char*){} template<class... T> void printf(const char*,T...){} };
static SilentLog diagnosticLog;
#include <lvgl.h>
#include <esp_timer.h>
#include <esp_heap_caps.h>
#include <esp_system.h>
#include <esp_wifi.h>
#include <atomic>
#include "OpeningArtwork.h"
#include <WiFi.h>
#include <Preferences.h>
#include <WebServer.h>
#include <Update.h>
#include "CloudUpdate.h"
#include "SignalQuality.h"
#include "Display_ST7701.h"
#include "I2C_Driver.h"
#include "TCA9554PWR.h"
#if CONFIG_ESP32S3_DATA_CACHE_LINE_SIZE != 64
#error "Use the matching esp32-3.0.2-h SDK: 64-byte cache is required."
#endif
#if !CONFIG_SPIRAM_FETCH_INSTRUCTIONS || !CONFIG_SPIRAM_RODATA
#error "Use the XIP-on-PSRAM SDK; ordinary precompiled SDK is not supported."
#endif

static constexpr uint32_t PIXELS=480*480, FRAME_BYTES=PIXELS*2;

enum Page {DIAGNOSTIC,OPEN,DASH,SETTINGS,NETWORKS,PASSWORD,UPDATES,LOCAL_UPDATES,SIGNAL};
static Preferences prefs;
static WebServer server(80);
static lv_disp_drv_t displayDriver;
static lv_disp_draw_buf_t drawBuffer;
static lv_img_dsc_t artwork={};
static const uint8_t *artPixels=OPENING_PIXELS;
static lv_obj_t *image=nullptr,*statusLabel=nullptr,*passwordBox=nullptr,*networkList=nullptr,*statusIcon=nullptr,*statusGlyph=nullptr;


static bool rgbActive=false,scanning=false,connecting=false,otaEnabled=false,uploadAllowed=false,uploadOK=false,uploadComplete=false,rebootPending=false;
static uint32_t connectStarted=0,otaStarted=0,rebootAt=0,lastStatus=0;
static String selectedSSID,otaPassword,otaToken;
static std::atomic<unsigned> disconnectReason{0};
static String pendingSSID,pendingPassword,wifiMessage="Wi-Fi off until Continue";
static bool saveAfterConnect=false,wasConnected=false,retrySaved=false,scanRequested=false,credentialsVerified=false;
static uint8_t scheduledAction=0,retryCount=0;
static uint32_t actionAt=0;
static unsigned lastFailureReason=0;
struct SavedNetwork {uint32_t magic;char ssid[33];char password[64];};
static bool loadNetwork(String &ssid,String &password){
 SavedNetwork n={};
 if(prefs.getBytesLength("network")==sizeof(n)&&prefs.getBytes("network",&n,sizeof(n))==sizeof(n)&&n.magic==0x4c4c5731&&n.ssid[32]==0&&n.password[63]==0&&n.ssid[0]){ssid=n.ssid;password=n.password;return true;}
 ssid=prefs.getString("ssid","");password=prefs.getString("pass","");return ssid.length()>0&&ssid.length()<=32&&password.length()<=63;
}
static void cancelNetwork(){
 WiFi.setAutoReconnect(false);esp_wifi_scan_stop();esp_wifi_disconnect();WiFi.scanDelete();
 scanning=false;connecting=false;scheduledAction=0;saveAfterConnect=false;wasConnected=false;retrySaved=false;scanRequested=false;pendingPassword="";wifiMessage="Wi-Fi disconnected\nSelect a network in Settings";
}
static void requestConnection(String ssid,String password,bool save,bool automatic=false){
 cancelNetwork();pendingSSID=ssid;pendingPassword=password;saveAfterConnect=save;scheduledAction=2;actionAt=millis()+350;retryCount=0;retrySaved=automatic;scanRequested=false;wifiMessage="Preparing connection...";
}
// Scanning must never cancel an established or pending connection.
static bool requestScan(){
 if(connecting||scheduledAction==2||scanning||scheduledAction==1)return false;
 WiFi.scanDelete();scheduledAction=1;actionAt=millis()+350;return true;
}
static void serviceRequestedScan(bool viewingNetworks){
 if(!viewingNetworks){scanRequested=false;return;}
 if(scanRequested){if(scanning||scheduledAction==1)scanRequested=false;else if(requestScan())scanRequested=false;}
}
static bool retryStoredNetwork(){
 String ssid,password;if(!loadNetwork(ssid,password))return false;
 requestConnection(ssid,password,false,true);return true;
}
static Page page=DIAGNOSTIC;
static void showDiagnostics();static void startRadio();static void showOpen();static void showDashboard();static void showSettings();static void showNetworks();static void showPassword();static void showUpdates();static void showLocalUpdates();static void showSignal();static void refreshSignal();
static lv_color_t blue(){return lv_color_hex(0x0a264f);}static lv_color_t sand(){return lv_color_hex(0xf5f3ea);}
static void flush(lv_disp_drv_t *d,const lv_area_t *a,lv_color_t *c){
 if(rgbActive)LCD_addWindow(a->x1,a->y1,a->x2,a->y2,(uint8_t*)c);
 lv_disp_flush_ready(d);
}
static void touch(lv_indev_drv_t*,lv_indev_data_t *d){
 uint16_t x[5]={},y[5]={};uint8_t n=0;Touch_Read_Data();
 if(Touch_Get_XY(x,y,nullptr,&n,5)&&n&&x[0]<480&&y[0]<480){d->point.x=x[0];d->point.y=y[0];d->state=LV_INDEV_STATE_PR;}else d->state=LV_INDEV_STATE_REL;
}
static void tick(void*){lv_tick_inc(2);}
static void suspendDisplay(){} // XIP SDK keeps PSRAM available during flash operations.
static void resumeDisplay(){}
static void initLVGL(){
 lv_init();auto *buf=(lv_color_t*)heap_caps_malloc(480*40*2,MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT);
 if(!buf){diagnosticLog.println("ERROR: draw buffer allocation");while(true)delay(1000);}
 lv_disp_draw_buf_init(&drawBuffer,buf,nullptr,480*40);lv_disp_drv_init(&displayDriver);
 displayDriver.hor_res=480;displayDriver.ver_res=480;displayDriver.flush_cb=flush;displayDriver.draw_buf=&drawBuffer;lv_disp_drv_register(&displayDriver);
 static lv_indev_drv_t input;lv_indev_drv_init(&input);input.type=LV_INDEV_TYPE_POINTER;input.read_cb=touch;lv_indev_drv_register(&input);
 const esp_timer_create_args_t args={.callback=tick,.arg=nullptr,.dispatch_method=ESP_TIMER_TASK,.name="lv_tick",.skip_unhandled_events=false};
 esp_timer_handle_t timer;ESP_ERROR_CHECK(esp_timer_create(&args,&timer));ESP_ERROR_CHECK(esp_timer_start_periodic(timer,2000));
}
static lv_obj_t* label(const char *text,int y,int width=330){auto *o=lv_label_create(lv_scr_act());lv_label_set_text(o,text);lv_obj_set_width(o,width);lv_obj_set_style_text_align(o,LV_TEXT_ALIGN_CENTER,0);lv_obj_set_style_text_color(o,blue(),0);lv_obj_align(o,LV_ALIGN_TOP_MID,0,y);return o;}
static lv_obj_t* button(const char *text,int y,lv_event_cb_t cb,int width=240){auto *o=lv_btn_create(lv_scr_act());lv_obj_set_size(o,width,46);lv_obj_align(o,LV_ALIGN_TOP_MID,0,y);lv_obj_set_style_bg_color(o,blue(),0);lv_obj_set_style_radius(o,23,0);auto *l=lv_label_create(o);lv_label_set_text(l,text);lv_obj_center(l);lv_obj_add_event_cb(o,cb,LV_EVENT_CLICKED,nullptr);return o;}
static void clearPage(Page next){page=next;if(next!=NETWORKS)scanRequested=false;statusIcon=statusGlyph=nullptr;statusLabel=passwordBox=networkList=image=nullptr;lv_obj_clean(lv_scr_act());lv_obj_clear_flag(lv_scr_act(),LV_OBJ_FLAG_SCROLLABLE);lv_obj_set_style_bg_color(lv_scr_act(),sand(),0);lv_obj_set_style_text_font(lv_scr_act(),&lv_font_montserrat_16,0);}
static String wifiStatus(){
 if(WiFi.status()==WL_CONNECTED)return String("Connected\n")+WiFi.SSID()+"\n"+WiFi.localIP().toString()+ (credentialsVerified?"\nSaved for next startup":"\nSettings not saved");
 if(connecting||scheduledAction==2)return String("Connecting...\nAttempt ")+String(unsigned(retryCount+1))+(retrySaved?" of 3":" of 1");
 if(scanning||scheduledAction==1)return "Scanning networks...";
 return wifiMessage;
}
static void showImage(){artwork.header.cf=LV_IMG_CF_TRUE_COLOR;artwork.header.w=480;artwork.header.h=480;artwork.data_size=FRAME_BYTES;artwork.data=artPixels;lv_img_cache_invalidate_src(&artwork);image=lv_img_create(lv_scr_act());lv_img_set_src(image,&artwork);lv_obj_center(image);}
static void showOpen(){clearPage(OPEN);showImage();button("Open",370,[](lv_event_t*){showDashboard();},160);}
static void refreshDashboard(){
 if(page!=DASH||!statusLabel)return;
 lv_label_set_text(statusLabel,wifiStatus().c_str());
 bool online=WiFi.status()==WL_CONNECTED;bool busy=connecting||scheduledAction==2||scanning||scheduledAction==1;
 lv_obj_set_style_bg_color(statusIcon,lv_color_hex(online?0x36bfaf:(busy?0x0a264f:0xf97370)),0);
 lv_label_set_text(statusGlyph,online?LV_SYMBOL_OK:(busy?"...":LV_SYMBOL_CLOSE));lv_obj_center(statusGlyph);
}
static void showDashboard(){
 clearPage(DASH);label("Trailhead Compass",70);label("Wireless update v0.1.10",110);
 statusIcon=lv_obj_create(lv_scr_act());lv_obj_remove_style_all(statusIcon);lv_obj_set_size(statusIcon,30,30);lv_obj_align(statusIcon,LV_ALIGN_TOP_LEFT,62,180);
 lv_obj_set_style_radius(statusIcon,LV_RADIUS_CIRCLE,0);lv_obj_set_style_bg_opa(statusIcon,LV_OPA_COVER,0);lv_obj_clear_flag(statusIcon,LV_OBJ_FLAG_SCROLLABLE|LV_OBJ_FLAG_CLICKABLE);
 statusGlyph=lv_label_create(statusIcon);lv_obj_set_style_text_color(statusGlyph,lv_color_hex(0xffffff),0);
 statusLabel=label("",180,300);lv_obj_align(statusLabel,LV_ALIGN_TOP_LEFT,104,180);lv_obj_set_style_text_align(statusLabel,LV_TEXT_ALIGN_LEFT,0);refreshDashboard();
 button("Settings",300,[](lv_event_t*){showSettings();});button("Alignment test",356,[](lv_event_t*){showDiagnostics();});
}
static void showSettings(){clearPage(SETTINGS);label("Settings",75);button("Wi-Fi",135,[](lv_event_t*){showNetworks();});auto *updates=button("Firmware updates",195,[](lv_event_t*){showUpdates();});if(cloudAvailable){auto *dot=lv_obj_create(updates);lv_obj_remove_style_all(dot);lv_obj_set_size(dot,14,14);lv_obj_align(dot,LV_ALIGN_RIGHT_MID,0,0);lv_obj_set_style_radius(dot,LV_RADIUS_CIRCLE,0);lv_obj_set_style_bg_color(dot,lv_color_hex(0xffc83d),0);lv_obj_set_style_bg_opa(dot,LV_OPA_COVER,0);}button("Wi-Fi signal",250,[](lv_event_t*){showSignal();});button("Forget Wi-Fi",305,[](lv_event_t*){
 cancelNetwork();prefs.remove("network");prefs.remove("ssid");prefs.remove("pass");credentialsVerified=false;wifiMessage="Saved network removed";showSettings();
 });button("Back",365,[](lv_event_t*){showDashboard();});}
// Diagnostics reads existing station data; it never scans or changes radio settings.
static lv_obj_t *signalBars[4]={};static lv_obj_t *signalReading=nullptr,*signalDetails=nullptr,*signalNetwork=nullptr;
static int signalMin=0,signalMax=-127;static unsigned signalSamples=0;
static void refreshSignal(){
 if(page!=SIGNAL)return;
 bool online=WiFi.status()==WL_CONNECTED;
 lv_label_set_text(signalNetwork,online?WiFi.SSID().c_str():"Not connected");
 int rssi=online?WiFi.RSSI():0;bool valid=online&&validSignal(rssi);
 if(valid){if(!signalSamples){signalMin=signalMax=rssi;}else {signalMin=min(signalMin,rssi);signalMax=max(signalMax,rssi);}signalSamples++;}
 char text[190];
 if(valid)snprintf(text,sizeof(text),"%d dBm - %s",rssi,signalQuality(rssi));
 else snprintf(text,sizeof(text),"%s",online?"Signal reading unavailable":"Wi-Fi disconnected");
 lv_label_set_text(signalReading,text);
 int bars=valid?signalBarCount(rssi):0;
 for(int i=0;i<4;i++)lv_obj_set_style_bg_color(signalBars[i],lv_color_hex(i<bars?(bars<=1?0xf97370:0x36bfaf):0xd7d9d8),0);
 if(valid)snprintf(text,sizeof(text),"Channel %d\nThis visit: %d to %d dBm\nCloser to 0 means stronger",WiFi.channel(),signalMin,signalMax);
 else snprintf(text,sizeof(text),"%s\nLast disconnect reason: %u",(connecting||scheduledAction==2)?"Reconnecting...":"Use Retry saved Wi-Fi below",disconnectReason.load());
 lv_label_set_text(signalDetails,text);
}
static void showSignal(){
 clearPage(SIGNAL);signalSamples=0;label("Wi-Fi signal",52);
 auto *ssid=label(WiFi.status()==WL_CONNECTED?WiFi.SSID().c_str():"Not connected",82,290);signalNetwork=ssid;lv_label_set_long_mode(ssid,LV_LABEL_LONG_DOT);lv_obj_set_height(ssid,22);
 for(int i=0;i<4;i++){auto *bar=lv_obj_create(lv_scr_act());signalBars[i]=bar;lv_obj_remove_style_all(bar);lv_obj_set_size(bar,26,14+i*12);lv_obj_set_pos(bar,170+i*36,178-(14+i*12));lv_obj_set_style_radius(bar,4,0);lv_obj_set_style_bg_opa(bar,LV_OPA_COVER,0);lv_obj_clear_flag(bar,LV_OBJ_FLAG_CLICKABLE|LV_OBJ_FLAG_SCROLLABLE);}
 signalReading=label("",195,340);signalDetails=label("",230,320);
 label("Signal levels are approximate",302,300);
 button("Retry saved Wi-Fi",337,[](lv_event_t*){if(!retryStoredNetwork())wifiMessage="No saved network";showDashboard();},230);
 button("Back",397,[](lv_event_t*){showSettings();},140);refreshSignal();
}
static void networkPicked(lv_event_t *e){selectedSSID=String((const char*)lv_event_get_user_data(e));showPassword();}
// SSIDs live in stable storage, never use the text as a printf format.
static String networkNames[20];
static void scanNetworks(){
 startRadio();scanRequested=true;
 if(statusLabel)lv_label_set_text(statusLabel,(connecting||scheduledAction==2)?"Will scan after connection attempt...":"Scanning networks...");
}
static void showNetworks(){
 clearPage(NETWORKS);label("Choose Wi-Fi",55);statusLabel=label("Scanning networks...",85);
 networkList=lv_list_create(lv_scr_act());lv_obj_set_size(networkList,330,220);lv_obj_align(networkList,LV_ALIGN_TOP_MID,0,115);
 button("Scan",350,[](lv_event_t*){scanNetworks();},180);button("Back",408,[](lv_event_t*){showSettings();},140);
 scanNetworks();
}
static void connectToNetwork(){
 String password=lv_textarea_get_text(passwordBox);
 if(password.length()!=0&&(password.length()<8||password.length()>63)){lv_label_set_text(statusLabel,"Use 8-63 characters");return;}
 requestConnection(selectedSSID,password,true);showDashboard();
}
static lv_obj_t *keyButtons[30]={};static bool upperCase=false;static int keyPage=0;
static const char *SYMBOLS="0123456789!\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~";
static void updateKeys(){
 for(int i=0;i<30;i++){
  String text;
  if(i<26){if(keyPage==0)text=String(char((upperCase?'A':'a')+i));else {int pos=(keyPage-1)*26+i;if(pos<(int)strlen(SYMBOLS))text=String(SYMBOLS[pos]);}}
  else if(i==26)text=keyPage?"ABC":(upperCase?"abc":"ABC");
  else if(i==27)text=keyPage?"More":"123";
  else if(i==28)text="Space";else text="Del";
  lv_label_set_text(lv_obj_get_child(keyButtons[i],0),text.c_str());
  if(text.length())lv_obj_clear_state(keyButtons[i],LV_STATE_DISABLED);else lv_obj_add_state(keyButtons[i],LV_STATE_DISABLED);
 }
}
static void keyPressed(lv_event_t *e){
 int i=(uintptr_t)lv_event_get_user_data(e);
 if(i==26){if(keyPage)keyPage=0;else upperCase=!upperCase;updateKeys();}
 else if(i==27){keyPage=keyPage==0?1:(keyPage==1?2:1);updateKeys();}
 else if(i==28)lv_textarea_add_text(passwordBox," ");
 else if(i==29)lv_textarea_del_char(passwordBox);
 else if(keyPage==0){char text[2]={char((upperCase?'A':'a')+i),0};lv_textarea_add_text(passwordBox,text);}
 else {int pos=(keyPage-1)*26+i;if(pos<(int)strlen(SYMBOLS)){char text[2]={SYMBOLS[pos],0};lv_textarea_add_text(passwordBox,text);}}
}
static void showPassword(){
 clearPage(PASSWORD);upperCase=false;keyPage=0;
 auto *title=label(selectedSSID.c_str(),61,240);lv_label_set_long_mode(title,LV_LABEL_LONG_DOT);lv_obj_set_height(title,22);lv_obj_align(title,LV_ALIGN_TOP_LEFT,145,61);
 auto *back=button(LV_SYMBOL_LEFT,55,[](lv_event_t*){showNetworks();},42);lv_obj_set_size(back,42,42);lv_obj_align(back,LV_ALIGN_TOP_LEFT,92,53);
 statusLabel=label("Password",87,280);
 passwordBox=lv_textarea_create(lv_scr_act());lv_obj_set_size(passwordBox,280,44);lv_obj_set_pos(passwordBox,100,110);lv_textarea_set_one_line(passwordBox,true);lv_textarea_set_password_mode(passwordBox,true);lv_textarea_set_max_length(passwordBox,63);
 String storedSSID,storedPassword;if(loadNetwork(storedSSID,storedPassword)&&storedSSID==selectedSSID){lv_textarea_set_text(passwordBox,storedPassword.c_str());lv_label_set_text(statusLabel,"Saved password");}
 for(int i=0;i<30;i++){
  auto *key=lv_btn_create(lv_scr_act());keyButtons[i]=key;
  lv_obj_set_size(key,48,42);lv_obj_set_pos(key,81+(i%6)*54,166+(i/6)*48);
  lv_obj_set_style_bg_color(key,blue(),0);lv_obj_set_style_radius(key,10,0);lv_obj_clear_flag(key,LV_OBJ_FLAG_SCROLLABLE);
  auto *text=lv_label_create(key);lv_obj_set_style_text_font(text,i>=26?&lv_font_montserrat_12:&lv_font_montserrat_16,0);lv_obj_center(text);
  lv_obj_add_event_cb(key,keyPressed,LV_EVENT_CLICKED,(void*)(uintptr_t)i);
 }
 updateKeys();button("Connect",407,[](lv_event_t*){connectToNetwork();},160);
}
static void showLocalUpdates(){clearPage(LOCAL_UPDATES);label("Firmware updates",65);if(WiFi.status()!=WL_CONNECTED){label("Connect Wi-Fi in Settings first.",155);button("Back",335,[](lv_event_t*){showSettings();});return;}
 String msg=otaEnabled?String("Open on this Wi-Fi network:\nhttp://")+WiFi.localIP().toString()+"/\nUser: admin\nPassword: "+otaPassword+"\nUpdate window: 10 minutes":"Enable a local update window.\nUse the app-only .bin file.\nKeep device power connected.";label(msg.c_str(),120,330);
 button(otaEnabled?"Disable updates":"Enable updates",310,[](lv_event_t*){otaEnabled=!otaEnabled;otaStarted=millis();showLocalUpdates();});button("Back",370,[](lv_event_t*){showSettings();});}
static bool authenticated(){return !cloudBusy&&otaEnabled&&WiFi.status()==WL_CONNECTED&&server.authenticate("admin",otaPassword.c_str());}
static void initOTA(){
 char pass[17],token[33];snprintf(pass,sizeof(pass),"%08lx%08lx",(unsigned long)esp_random(),(unsigned long)esp_random());otaPassword=pass;
 snprintf(token,sizeof(token),"%08lx%08lx%08lx%08lx",(unsigned long)esp_random(),(unsigned long)esp_random(),(unsigned long)esp_random(),(unsigned long)esp_random());otaToken=token;
 const char *headers[]={"X-Update-Token"};server.collectHeaders(headers,1);
 server.on("/",HTTP_GET,[]{if(!otaEnabled){server.send(403,"text/plain","Enable updates on the device first.");return;}if(!authenticated()){server.requestAuthentication();return;}
 String html=R"HTML(<!doctype html><meta name="viewport" content="width=device-width"><title>Trailhead Update</title><h1>Trailhead Compass</h1><p>Choose the app-only .bin. Keep device power connected.</p><input type="file" id="f" accept=".bin"><button id="upload">Upload firmware</button><progress id="progress" value="0" max="100"></progress><pre id="s"></pre><script>
const token=')HTML"+otaToken+R"HTML(';
document.getElementById('upload').onclick=()=>{
 const f=document.getElementById('f'),button=document.getElementById('upload'),s=document.getElementById('s'),p=document.getElementById('progress');
 if(!f.files.length)return;const file=f.files[0];if(file.size>4194304||!file.name.endsWith('-app.bin')){s.textContent='Choose an app-only firmware file, up to 4 MB.';return;}
 button.disabled=true;f.disabled=true;s.textContent='Uploading 0%. Keep power connected.';const xhr=new XMLHttpRequest();xhr.open('POST','/update');xhr.timeout=600000;xhr.setRequestHeader('X-Update-Token',token);
 const finish=()=>{button.disabled=false;f.disabled=false;};
 xhr.upload.onprogress=e=>{if(e.lengthComputable){p.value=Math.round(e.loaded*100/e.total);s.textContent=p.value<100?'Uploading '+p.value+'%. Keep power connected.':'Upload sent. Device is verifying and saving. Keep power connected.';}};
 xhr.onload=()=>{s.textContent=xhr.responseText||('HTTP '+xhr.status);finish();};xhr.onerror=()=>{s.textContent='Connection lost. Check the version on the device before retrying.';finish();};xhr.ontimeout=()=>{s.textContent='No reply after 10 minutes. Check the device before retrying.';finish();};const data=new FormData();data.append('firmware',file);xhr.send(data);
};</script>)HTML";server.sendHeader("Cache-Control","no-store");server.send(200,"text/html",html);
 });
 server.on("/update",HTTP_POST,[]{if(!uploadAllowed){server.send(403,"text/plain","Update not authorized.");return;}
 bool ok=uploadAllowed&&uploadComplete&&uploadOK&&!Update.hasError();server.send(ok?200:400,"text/plain",ok?"Update complete. Restarting...":"Update failed. Existing firmware remains selected.");if(ok){rebootPending=true;rebootAt=millis()+1200;}else resumeDisplay();uploadAllowed=false;
 },[]{auto &u=server.upload();if(u.status==UPLOAD_FILE_START){uploadAllowed=authenticated()&&server.header("X-Update-Token")==otaToken;uploadOK=false;uploadComplete=false;if(!uploadAllowed)return;suspendDisplay();uploadOK=Update.begin(UPDATE_SIZE_UNKNOWN,U_FLASH);}
 else if(u.status==UPLOAD_FILE_WRITE){if(uploadAllowed&&uploadOK&&Update.write(u.buf,u.currentSize)!=u.currentSize)uploadOK=false;}
 else if(u.status==UPLOAD_FILE_END){if(uploadAllowed){if(uploadOK){uploadOK=Update.end(true);uploadComplete=uploadOK;}else Update.abort();if(!uploadOK)resumeDisplay();}}
 else if(u.status==UPLOAD_FILE_ABORTED){if(uploadAllowed){Update.abort();uploadOK=false;uploadComplete=false;uploadAllowed=false;resumeDisplay();}}
 });server.begin();
}

static lv_obj_t *cloudProgress=nullptr;
static void showUpdates(){
 clearPage(UPDATES);label("Firmware updates",55);label("Installed v" TRAILHEAD_VERSION " / test",85);
 cloudProgress=label(cloudMessage,120,310);
 if(cloudBusy){label("Keep device power connected",335);return;}
 if(cloudAvailable){
  String details=String("Available v")+cloudRelease.version+"\n"+cloudRelease.notes;
  auto *notes=label(details.c_str(),175,300);lv_obj_set_height(notes,100);lv_label_set_long_mode(notes,LV_LABEL_LONG_WRAP);
  button("Download & install",290,[](lv_event_t*){if(startCloudJob(true)){otaEnabled=false;showUpdates();}},230);
 }else button("Check for updates",290,[](lv_event_t*){startCloudJob(false);showUpdates();},230);
 button("Local upload",345,[](lv_event_t*){showLocalUpdates();},190);
 button("Back",400,[](lv_event_t*){showSettings();},130);
}
static void serviceCloudUpdates(uint32_t now){
 bool changed=receiveCloudEvent();
 if(changed){if(page==UPDATES){if(cloudBusy&&cloudProgress)lv_label_set_text(cloudProgress,cloudMessage);else showUpdates();}else if(page==SETTINGS)showSettings();}
 if(cloudRestart){rebootPending=true;rebootAt=now+2000;cloudRestart=false;}
 static bool wasOnline=false;static uint32_t onlineAt=0,lastCheck=0;static bool checked=false;
 bool online=WiFi.status()==WL_CONNECTED;
 if(online&&!wasOnline){onlineAt=now;checked=false;}wasOnline=online;
 if(online&&!cloudBusy&&!otaEnabled&&!uploadAllowed&&!rebootPending&&!connecting&&!scanning&&!scheduledAction&&((!checked&&now-onlineAt>10000)||(checked&&now-lastCheck>21600000))){
  if(startCloudJob(false)){checked=true;lastCheck=now;if(page==UPDATES)showUpdates();}
 }
}
static bool radioStarted=false;
static void startRadio(){
 if(radioStarted)return;
 WiFi.onEvent([](WiFiEvent_t e,WiFiEventInfo_t info){
  if(e==ARDUINO_EVENT_WIFI_STA_DISCONNECTED){disconnectReason.store(info.wifi_sta_disconnected.reason);diagnosticLog.printf("Wi-Fi disconnect reason: %u\n",unsigned(info.wifi_sta_disconnected.reason));}
 });
 WiFi.mode(WIFI_STA);WiFi.setAutoReconnect(false);radioStarted=true;initOTA();
 String ssid,password;credentialsVerified=loadNetwork(ssid,password);if(credentialsVerified)requestConnection(ssid,password,false,true);else wifiMessage="Wi-Fi disconnected\nChoose a network in Settings";
}
static lv_obj_t *tapLabel=nullptr;static uint32_t tapCount=0;
static void showDiagnostics(){
 clearPage(DIAGNOSTIC);tapCount=0;
 auto *ring=lv_obj_create(lv_scr_act());lv_obj_set_size(ring,440,440);lv_obj_center(ring);
 lv_obj_set_style_radius(ring,LV_RADIUS_CIRCLE,0);lv_obj_set_style_bg_opa(ring,LV_OPA_TRANSP,0);
 lv_obj_set_style_border_color(ring,blue(),0);lv_obj_set_style_border_width(ring,2,0);
 lv_obj_clear_flag(ring,LV_OBJ_FLAG_CLICKABLE|LV_OBJ_FLAG_SCROLLABLE);
 auto *horizontal=lv_obj_create(lv_scr_act());lv_obj_remove_style_all(horizontal);lv_obj_set_size(horizontal,100,2);lv_obj_center(horizontal);lv_obj_set_style_bg_color(horizontal,blue(),0);lv_obj_set_style_bg_opa(horizontal,LV_OPA_COVER,0);
 auto *vertical=lv_obj_create(lv_scr_act());lv_obj_remove_style_all(vertical);lv_obj_set_size(vertical,2,100);lv_obj_center(vertical);lv_obj_set_style_bg_color(vertical,blue(),0);lv_obj_set_style_bg_opa(vertical,LV_OPA_COVER,0);
 label("Display check v0.1.10",70);label("Ring and cross must stay fixed",105);
 tapLabel=label("Tap count: 0",145);
 button("Tap test",305,[](lv_event_t*){tapCount++;lv_label_set_text_fmt(tapLabel,"Tap count: %lu",(unsigned long)tapCount);});
 button("Continue",365,[](lv_event_t*){startRadio();showOpen();},180);
 diagnosticLog.println("DISPLAY TEST: 10MHz / 64-byte cache / XIP; radio initially off");
}

static void serviceNetwork(uint32_t now){
 if(scheduledAction&&int32_t(now-actionAt)>=0){
  uint8_t action=scheduledAction;scheduledAction=0;disconnectReason.store(0);
  if(action==1){int n=WiFi.scanNetworks(true,true);scanning=n==WIFI_SCAN_RUNNING;if(statusLabel&&page==NETWORKS)lv_label_set_text(statusLabel,scanning?"Scanning...":"Scan failed. Tap Rescan.");}
  else {diagnosticLog.println("Starting Wi-Fi connection (password hidden)");wl_status_t result=WiFi.begin(pendingSSID.c_str(),pendingPassword.c_str());connecting=result!=WL_CONNECT_FAILED;connectStarted=now;if(!connecting){wifiMessage="Could not start connection\nRetry from Settings";saveAfterConnect=false;pendingPassword="";}}
 }
 if(connecting&&WiFi.status()==WL_CONNECTED){
  connecting=false;wasConnected=true;wifiMessage="Connected";
  if(saveAfterConnect){SavedNetwork n={};n.magic=0x4c4c5731;pendingSSID.toCharArray(n.ssid,sizeof(n.ssid));pendingPassword.toCharArray(n.password,sizeof(n.password));size_t count=prefs.putBytes("network",&n,sizeof(n));diagnosticLog.println(count==sizeof(n)?"Network saved":"ERROR: network save failed");String verifySSID,verifyPassword;credentialsVerified=count==sizeof(n)&&loadNetwork(verifySSID,verifyPassword)&&verifySSID==pendingSSID&&verifyPassword==pendingPassword; if(!credentialsVerified)wifiMessage="Connected; settings save failed";}
  saveAfterConnect=false;pendingPassword="";retryCount=0;
 }
 if(connecting&&now-connectStarted>=30000){
  connecting=false;lastFailureReason=disconnectReason.load();esp_wifi_disconnect();saveAfterConnect=false;
  if(retrySaved&&retryCount<2&&!scanRequested){retryCount++;scheduledAction=2;actionAt=now+5000;}
  else {pendingPassword="";retrySaved=false;wifiMessage=String("Connection failed; reason ")+lastFailureReason+"\nRetry saved Wi-Fi in Settings";}
 }
 if(wasConnected&&!scanning&&scheduledAction!=1&&WiFi.status()!=WL_CONNECTED){
  wasConnected=false;wifiMessage=String("Connection lost; reason ")+disconnectReason.load();String ssid,password;
  if(retryCount<3&&loadNetwork(ssid,password)){requestConnection(ssid,password,false,true);retryCount=0;actionAt=now+5000;}
 }
}
void setup(){
 diagnosticLog.begin(115200);diagnosticLog.println("LegacyLink Trailhead 0.1.10");
 WiFi.persistent(false);WiFi.mode(WIFI_OFF);prefs.begin("trailhead",false); // Before LCD starts: may initialize NVS.
 I2C_Init();delay(120);TCA9554PWR_Init(0x00);Set_EXIO(EXIO_PIN8,Low);LCD_Init();rgbActive=true;
 initLVGL();Set_Backlight(60);
 showDiagnostics();
}
void loop(){
 uint32_t now=millis();if(rebootPending&&int32_t(now-rebootAt)>=0)ESP.restart();
 if(!rebootPending&&radioStarted&&!cloudBusy)server.handleClient();
 if(otaEnabled&&!uploadAllowed&&now-otaStarted>600000){otaEnabled=false;if(page==LOCAL_UPDATES)showLocalUpdates();}

 if(scanning){int n=WiFi.scanComplete();if(n>=0){scanning=false;if(page==NETWORKS&&networkList){lv_obj_clean(networkList);int count=0;for(int i=0;i<n&&count<20;i++){String s=WiFi.SSID(i);if(!s.length())continue;bool dup=false;for(int j=0;j<count;j++)if(networkNames[j]==s)dup=true;if(dup)continue;networkNames[count]=s;auto *b=lv_list_add_btn(networkList,nullptr,s.c_str());lv_obj_add_event_cb(b,networkPicked,LV_EVENT_CLICKED,(void*)networkNames[count].c_str());count++;}lv_label_set_text(statusLabel,count?"Tap a network":"No visible networks. Tap Rescan.");}WiFi.scanDelete();}else if(n==WIFI_SCAN_FAILED){scanning=false;if(page==NETWORKS&&statusLabel)lv_label_set_text(statusLabel,"Scan failed. Tap Rescan.");}}
 if(!cloudBusy)serviceNetwork(now);
 serviceCloudUpdates(now);
 serviceRequestedScan(page==NETWORKS);
 if(now-lastStatus>1000){lastStatus=now;if(page==DASH&&statusLabel)refreshDashboard();if(page==SIGNAL)refreshSignal();}
 if(rgbActive)lv_timer_handler();delay(5);
}
